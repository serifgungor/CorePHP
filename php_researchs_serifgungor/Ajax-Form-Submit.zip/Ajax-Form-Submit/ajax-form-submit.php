<?php
	echo "From Server".json_encode($_POST)."<br>";
?>