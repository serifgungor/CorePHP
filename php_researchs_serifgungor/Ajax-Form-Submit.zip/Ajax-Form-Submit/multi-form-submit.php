<?php
	echo "FILES =".json_encode($_FILES)."<br><br>";
	echo "POST =".json_encode($_POST)."<br>";
?>