# PHP-CEKILIS
PHP ile hazırlanmış, çekiliş uygulamasıdır. Kullanıcıdan aldığı, kişi listesi ve kazanan sayısına göre çekiliş yapar ve kazanan listesini geri döndürür.

Katkıda bulunanlar : Özgür Akıncı(PHP), Ferdi Şahin(Tasarım), tiwaly(wmaraci/PHP)

Link 1 = http://ozgurakinci.com/upload/projects/php/php-raffle/
