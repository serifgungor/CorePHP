<?php 
	$save = false; //Çekilişlerin dosya olarak kayıt edilmesini istiyorsanız True, istemiyorsanız False yazınız.

 ?>