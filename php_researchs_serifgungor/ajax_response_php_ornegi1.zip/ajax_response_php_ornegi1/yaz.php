<?php
error_reporting(E_ALL & ~E_NOTICE);
ini_set('error_reporting', E_ALL & ~E_NOTICE);  //oluşabilecek hataları gizliyoruz
 
$isim = $_POST[ "isim" ];
$soyad = $_POST[ "soyad" ];
if(empty($isim) || empty($soyad)) { 
    echo "Lütfen boş alan birakmayin.";
}else { 
    echo $isim." ".$soyad; 
}
?>