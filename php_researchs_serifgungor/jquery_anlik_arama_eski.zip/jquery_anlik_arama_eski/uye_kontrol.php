<?php
$gelen = strip_tags(trim($_GET["uye"])); //Gelen kullanici adini aldik.
 
include "baglan.php"; //Mysql baglanti dosyasini �agirdik.
 
$uye_kontrol_sorgu = mysql_query("SELECT * FROM uyeler WHERE kullanici_adi='$gelen'"); //Uyeler tablosunda, gelen kullanici adini arattik.
$uye_kontrol = mysql_num_rows($uye_kontrol_sorgu); //�ikan sonu� sayisini saydirdik.
 
if($uye_kontrol > 0) { //Eger �ye mevcutsa, 1 yazdirdik.
    echo "1";
}else { //�ye mevcut degilse, 0 yazdirdik.
    echo "0";
}
?>