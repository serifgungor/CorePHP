 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
 <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
 <title></title>
 <script src="jquery/jquery-latest.min.js" type="text/javascript"></script>
 <style type="text/css">
 body{min-width:600px;}
 div{float:left;margin:1vh;padding:1vw;border:1vh solid #ccc;height:90vh;}
 .AdminMenu{width:15vw;}
 .Icerik{width:70vw;}
 </style>
</head>
<body>
<span id="Kapsa">
 <div class="AdminMenu">
   <p><a data="beta.php" class="adminlink">beta.php</a>   </p>
   <p><a data="test.php" class="adminlink">test.php</a>
     <script>
$( ".adminlink" ).click(function() {
 var link = $( this ).attr( "data" );
 $.ajax({url: link,success: function(data) { $('.Icerik').html(data);}});
});

     </script>
   </p>
 </div>
 <div class="Icerik">
 ben bir varsayılan içeriğim<br>
 tıklanan linkteki html içerikler benimle değişir.
 </div>
</span>
</body>
</html>