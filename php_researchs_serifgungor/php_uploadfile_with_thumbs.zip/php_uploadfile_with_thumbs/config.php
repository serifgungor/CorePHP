<?php
$final_width_of_image = 100;
$path_to_image_directory = 'images/fullsized/';
$path_to_thumbs_directory = 'images/thumbs/';
?>